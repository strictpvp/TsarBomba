<p align="center">
    <img style="height: 200px" src="src/main/resources/assets/reich/icon.png" />
</p>

<h1 align="center">Tsar Bomba</h1>
<p align="center">Crasher Addon For Meteor</p>
